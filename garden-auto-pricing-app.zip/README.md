# Garden Auto Pricing App (20% Markup)

This mini app lets you select Brand/Model/Part, fetch competitor prices via SerpAPI (Google Shopping),
compute a 20% markup, auto-fill unit price, update invoice totals, and cache prices locally.

## Quick Start (local test without SerpAPI)
1) Unzip the package.
2) Run: `npm install`
3) Run: `npm start`
4) Open http://localhost:3000
- If you did **not** set a SERPAPI_KEY, the page will fall back to mock prices so you can test the flow.

## Use real Google Shopping data (SerpAPI)
- Create a free SerpAPI account and get an API key.
- Set the env variable before starting:
    - macOS/Linux: `export SERPAPI_KEY=YOUR_KEY && npm start`
    - Windows (Powershell): `$env:SERPAPI_KEY="YOUR_KEY"; npm start`

## Files
- `server.js` — Express server and `/api/shopping` proxy (keeps your key off the client).
- `public/index.html` — Frontend UI (items table, parts required, invoice preview, print).
- `package.json` — project config.
- This server also serves the static web app.

## What it does
- On part selection: calls `/api/shopping?q=...` with multiple queries (brand/model/part), parses competitor prices,
  trims outliers, takes the median, applies +20% markup, and fills the unit price.
- Autosaves computed prices in `localStorage` (keyed by `brand|model|part`) and background-refreshes later.
- Shows an invoice preview with Parts Required, labour, GST, and totals; supports printing.
