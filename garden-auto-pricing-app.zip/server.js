// server.js
import express from 'express';
import fetch from 'node-fetch';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

const SERPAPI_KEY = process.env.SERPAPI_KEY;

// Proxy endpoint to SerpAPI Google Shopping (keeps API key off the client)
app.get('/api/shopping', async (req, res) => {
  try {
    const { q, num = 10, location = 'Melbourne, Victoria, Australia' } = req.query;
    if (!q) return res.status(400).json({ error: 'Missing q' });
    if (!SERPAPI_KEY) {
      return res.status(200).json({ shopping_results: [], note: "No SERPAPI_KEY set on server. Return empty array so client uses mock." });
    }
    const params = new URLSearchParams({
      engine: 'google_shopping',
      q,
      location,
      hl: 'en',
      gl: 'au',
      num: String(num),
      api_key: SERPAPI_KEY
    });
    const r = await fetch(`https://serpapi.com/search.json?${params.toString()}`);
    const json = await r.json();
    return res.status(r.ok ? 200 : 500).json(json);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'shopping proxy failed', detail: String(e) });
  }
});

// Serve static app
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
